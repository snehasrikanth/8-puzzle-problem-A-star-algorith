Instruction to run the code:
Run the puzzle_solver.py
1.Give the input for the initial state
Enter the input values for initial state
Enter the values:
Enter the values:
.
.
.
2.Next give the input for th goal state
Enter the input values for goal state
Enter the values:
Enter the values:
.
.
.
3.Then th program asks for the user input to calculate the following heuristic.
Select the heuristic you want 1.Misplaced Title 2.Manhattan Distance.
4.If 1.Misplaced title is given corresponding calculation will be executed and the output will be displayed.
   If 2.Manhattan Distance is given corresponding calculation will be executed and the output will be displayed.

IDE'S tested on:VS code,Pycharm.
